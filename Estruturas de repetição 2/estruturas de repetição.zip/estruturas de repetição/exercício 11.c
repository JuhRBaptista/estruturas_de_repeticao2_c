# include <stdio.h>

int main ()
{
    int numeroDoMenu, quantidadeRelativaADeposito = 0, quantidadeRelativaARetirada = 0, 
    quantidadeRelativaASaldo = 0, quantidadeRelativaAExtrato = 0;

    numeroDoMenu = 0;
    do 
    {
        printf ("\n1- Depósito\n2- Retirada\n3- Saldo\n4- Extrato\n5- Sair do programa");
        printf ("\n\nSelecione o número desejado do Menu: ");
        scanf ("%d", &numeroDoMenu);
        switch (numeroDoMenu)
        {
            case 1: printf ("\nVocê selecionou 'Depósito'.\n");
            quantidadeRelativaADeposito = quantidadeRelativaADeposito + 1;
            break;
            case 2: printf ("\nVocê selecionou 'Retirada'.\n");
            quantidadeRelativaARetirada = quantidadeRelativaARetirada + 1;
            break;
            case 3: printf ("\nVocê selecionou 'Saldo'.\n");
            quantidadeRelativaASaldo = quantidadeRelativaASaldo + 1;
            break;
            case 4: printf ("\nVocê selecionou 'Extrato'.\n");
            quantidadeRelativaAExtrato = quantidadeRelativaAExtrato + 1;
            break;
            case 5: printf ("\nVocê selecionou 'Sair do Programa'\n\n");
            break;
            default: printf ("\nOpção Inválida\n");
            break;
        }

    }
    while (numeroDoMenu != 5);
    printf ("Quantidades de operações efetuadas:\nDepósito: %i\nRetirada: %i\nSaldo: %i\nExtrato: %i\n",
    quantidadeRelativaADeposito, quantidadeRelativaARetirada, quantidadeRelativaASaldo, quantidadeRelativaAExtrato);
    printf ("\n\n\n");
    return 0;
}