# include <stdio.h>

int main ()
{ 
    float numeroRecebido;

    numeroRecebido = 0;
    while (numeroRecebido >= 0)
    {
        printf ("Insira um número: ");
        scanf ("%f", &numeroRecebido);
    }
    printf ("\n\n\n");
    return 0;
}