#include <stdio.h>

int main ()
{
    int somaDosNumeros = 0, numero;

    numero = 1;
    while (numero < 1000)
    {
        if ((numero % 3 == 0) || (numero % 5 == 0))
        {
            somaDosNumeros = somaDosNumeros + numero;
        }
        numero = numero + 1;
    }
    printf ("A soma dos números múltiplos de 3 e de 5, menores do que 1000, é igual a %d\n\n\n", somaDosNumeros);
    return 0;
}