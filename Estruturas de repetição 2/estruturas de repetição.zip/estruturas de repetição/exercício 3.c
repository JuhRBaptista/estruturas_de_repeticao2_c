#include <stdio.h>

int main ()
{
    int numero, somaDosNumeros = 0;

    for (numero = 1; numero <= 1000; numero ++)
    {
        somaDosNumeros = somaDosNumeros + numero;
    }
    printf ("A soma total dos números de 1 a 1000 é igual a %i\n\n\n", somaDosNumeros);
    return 0;
}