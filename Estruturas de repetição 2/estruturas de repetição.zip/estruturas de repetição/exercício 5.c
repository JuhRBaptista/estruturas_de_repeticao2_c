#include <stdio.h> 

int main ()
{
    int numero;
    for (numero = 200; numero >= 100; numero --)
    { 
        printf (" %i  ", numero);
    }
    printf ("\n\n\n");
    return 0;
}