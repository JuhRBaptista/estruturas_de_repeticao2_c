#include <stdio.h>

int main ()
{
    float somaDosNumerosAteN = 0;
    int valorDeN, numero;

    printf ("Insira um número N inteiro: ");
    scanf ("%i", &valorDeN);
    for (numero = 1; numero <= valorDeN; numero ++)
    {
        somaDosNumerosAteN = somaDosNumerosAteN + numero;
    }
    printf ("\nA soma dos números de 1 até o valor N informado é igual a %.0f\n\n\n", somaDosNumerosAteN);
    return 0;
}