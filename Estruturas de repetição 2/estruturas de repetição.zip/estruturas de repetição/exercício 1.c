#include <stdio.h>

int main ()
{
    float numeroInformado, somaDosNumerosInformados = 0;
    int quantidadeDeNumerosInformados;

    for (quantidadeDeNumerosInformados = 1; quantidadeDeNumerosInformados <= 10; quantidadeDeNumerosInformados ++)
    {
        printf ("\nInsira o número desejado: ");
        scanf ("%f", &numeroInformado);
        somaDosNumerosInformados = somaDosNumerosInformados + numeroInformado;
    }
    printf ("A soma total dos números informados é igual a %.2f\n\n\n", somaDosNumerosInformados);
    return 0;
}