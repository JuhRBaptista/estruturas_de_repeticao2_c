#include <stdio.h> 

int main ()
{
    int numero, limiteSuperiorDoIntervalo, limiteInferiorDoIntervalo;

    printf ("Insira o límite superior: ");
    scanf ("%d", &limiteSuperiorDoIntervalo);
    printf ("Insira o límite inferior: ");
    scanf ("%d", &limiteInferiorDoIntervalo); 

    for (numero = limiteInferiorDoIntervalo; numero <= limiteSuperiorDoIntervalo; numero++)
    {
        
      if (numero % 2 == 0)
      {
        printf ("%d ", numero);
      } 
    }
    printf ("\n\n\n");
    return 0;
}