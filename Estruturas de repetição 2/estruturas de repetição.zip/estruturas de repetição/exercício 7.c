#include <stdio.h>

int main ()
{
    int numero, valorDeN;
    
    printf ("Insira um número N: ");
    scanf ("%i", &valorDeN);
    for (numero = 7; numero <= valorDeN; numero += 7)
    {
        printf ("%d ", numero);
    }
    printf ("\n\n\n");
    return 0;
}