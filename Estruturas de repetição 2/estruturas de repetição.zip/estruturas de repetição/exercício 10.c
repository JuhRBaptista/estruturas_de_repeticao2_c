# include <stdio.h> 

int main ()
{
    float primeiroNumero, segundoNumero, produtoEntreOsDoisNumeros = 0;
    int quantidadeDeSomas;

    printf ("Insira um número: ");
    scanf ("%f", &primeiroNumero);
    printf ("Insira um segundo número: ");
    scanf ("%f", &segundoNumero);
    for (quantidadeDeSomas = 1; quantidadeDeSomas <= segundoNumero; quantidadeDeSomas ++)
    {
        produtoEntreOsDoisNumeros = produtoEntreOsDoisNumeros + primeiroNumero;
    }
    printf ("%.2f vezes %.2f é igual a %.2f\n\n\n", primeiroNumero, segundoNumero, produtoEntreOsDoisNumeros);
    return 0;
}