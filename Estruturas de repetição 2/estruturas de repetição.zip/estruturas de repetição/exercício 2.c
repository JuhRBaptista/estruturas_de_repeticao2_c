#include <stdio.h>

int main ()
{
    float numeroInformado, somaDosNumerosInformados = 0;
    int quantidadeDeNumerosInformados;

    quantidadeDeNumerosInformados = 1;
    while (quantidadeDeNumerosInformados <= 100)
    {
        printf ("Insira o número desejado: ");
        scanf ("%f", &numeroInformado);
        somaDosNumerosInformados = somaDosNumerosInformados + numeroInformado;
        quantidadeDeNumerosInformados = quantidadeDeNumerosInformados + 1;
    }
    printf ("A soma total dos números informados é igual a %.2f\n\n\n", somaDosNumerosInformados);
    return 0;
}